<?php if ( is_tax( 'game_category' ) ) : ?>
<?php $term_id = 'game_category_' . $args['page_id']; ?>
<?php elseif(is_tax( 'casino_type' )): ?>
<?php $term_id = 'casino_type_' . $args['page_id']; ?>
<?php else : ?>
<?php $term_id = $args['page_id']; ?>
<?php endif; ?>
<div class="casino_block">
    <h2 class="title_h2"><?php the_field( 'best_casino_block_title', $term_id ); ?></h2>
    <p class="desc"><?php the_field( 'best_casino_block_desc', $term_id ); ?></p>
    <?php if ( get_field( 'enable_subscribe_form', $term_id ) ) : ?>
        <?php get_template_part( 'template_parts/modal', 'subscribe', array( 'term_id' => $term_id ) ); ?>
    <?php endif; ?>
    <?php
    $casino_items = get_field( 'best_casino_items', $term_id );
    if ( $casino_items ) :
        ?>
        <div class="items_block">
            <?php
            foreach ( $casino_items as $casino_id ) :
                $item = get_post( $casino_id );

                $reflink = get_posts( array(
                    'numberposts'       => 1,
                    'post_type'         => 'reflink',
                    'post_parent'       => $casino_id
                ) );
                $rep = get_field('main_links', $reflink[0]->ID);
                $home_link = '';
                if ($rep) {
                    foreach ($rep as $r) {
                        if ($r['title'] == 'home_link')
                            $home_link = $r['referal_link'];
                    }
                }

                $bonus_id = get_field( 'start_bonus', $casino_id );
                $tms = wp_get_post_terms( $bonus_id, 'bonus_category', array( 'fields' => 'names' ) );
                $bonus_cat = $tms ? $tms[0] : '';
                ?>
                <div class="casino_item">
                    <div class="casino_name">
                        <a href="<?= get_permalink( $casino_id ); ?>" class="review_link"><img src="<?= wp_get_attachment_url( get_field( 'casino_logo_horizontal', $casino_id ) );?>" alt=""></a>
                        <div class="casino_rating">
                            <img loading="lazy" src="<?= get_template_directory_uri() ?>/assets/img/rating.png" alt=""/>
                            <span><?= get_field( 'rating', $casino_id ); ?></span>
                        </div>
                    </div>
                    <p class="casino_bonus">
                        <?= get_field( 'bonus_size', $bonus_id ) ? get_field( 'bonus_size', $bonus_id ) . ' AUD' : ''; ?>
                        <?= ( get_field( 'bonus_size', $bonus_id ) && get_field( 'free_spins', $bonus_id ) ) ? ' + ' : ''; ?>
                        <?= get_field( 'free_spins', $bonus_id ) ? get_field( 'free_spins', $bonus_id ) . ' FS' : ''; ?>
                    </p>
                    <div class="casino_medal">
                        <?php $medal_type = get_field( 'medal', $casino_id ); ?>
                        <img loading="lazy" src="<?= get_medal_image( $medal_type ); ?>" alt="">
                        <p class="medal_type"><?= $medal_type; ?></p>
                    </div>
                    <div class="casino_cons">
                        <?php
                        $cons_object = get_field_object( 'cons', $casino_id );
                        $choices = $cons_object['choices'];
                        $values = $cons_object['value'];
                        if ( $choices ) :
                            foreach ( $choices as $choice ) :
                                ?>
                                <div class="cons_item">
                                    <?php if ( in_array( $choice, $values ) ) : ?>
                                        <img loading="lazy" class="cons_img" src="<?= get_template_directory_uri() ?>/assets/img/icons/checked.png" alt="">
                                    <?php else : ?>
                                        <img loading="lazy" class="cons_img" src="<?= get_template_directory_uri() ?>/assets/img/icons/not-checked.png" alt="">
                                    <?php endif; ?>
                                    <p class="cons_text"><?= $choice; ?></p>
                                </div>
                            <?php
                            endforeach;
                        endif;
                        ?>
                    </div>
                    <div class="casino_buttons">
                        <a href="<?= $home_link; ?>" class="play_button">Play Now</a>
                        <!--<a href="<?= get_permalink( $casino_id ); ?>" class="review_button">Read Review</a>-->
                    </div>
                </div>
            <?php endforeach; ?>
            <?php if ( !is_tax( 'casino_type' ) ): ?>
                <a href="/real-money-casinos/" class="all_button">All Casino</a>
            <?php endif; ?>

        </div>
    <?php endif; ?>


</div>