<?php if ( is_tax( 'game_category' ) ) : ?>
    <?php $term_id = 'game_category_' . $args['page_id']; ?>
<?php elseif(is_tax( 'casino_type' )): ?>
    <?php $term_id = 'casino_type_' . $args['page_id']; ?>
<?php else : ?>
    <?php $term_id = $args['page_id']; ?>
<?php endif; ?>

<div class="benefits_block">
    <div class="wrapper p_0">
        <?php if(get_field('benefits_-_title', $term_id )):  ?>
            <h2 class="title_h2 text_left"><?php the_field( 'benefits_-_title', $term_id ); ?></h2>
        <?php endif; ?>
        <?php if(get_field('benefits_-_desc', $term_id )):  ?>
            <span class="text"><?php the_field( 'benefits_-_desc', $term_id ); ?></span>
        <?php endif; ?>
        <?php if( have_rows('benefits_-_cards',$term_id) ): ?>
            <div class="benefits_cards">
                <?php while( have_rows('benefits_-_cards',$term_id) ): the_row(); ?>
                    <div class="item">
                        <div class="benefit_item">
                            <picture><img src="<?php echo get_template_directory_uri();?>/assets/img/b_circle.png" alt=""></picture>
                            <div class="benefit_item_text">
                                <div class="benefit_item_text_title"><?php the_sub_field('benefits_-_cards_title',$term_id); ?></div>
                                <div class="text benefit_item_text_desc"> <?php the_sub_field('benefits_-_cards_desc',$term_id); ?></div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
