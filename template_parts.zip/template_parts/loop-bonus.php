<?php
    $bonus_id = $args['bonus_id'];
    $casino_id = get_post_parent( $bonus_id );
    $tms = wp_get_post_terms( $bonus_id, 'bonus_category', array( 'fields' => 'names' ) );
    $bonus_cat = $tms ? $tms[0] : '';
    $i = $args['increm'] ? $args['increm'] : '';
    $reflink = get_posts( array(
        'numberposts'       => 1,
        'post_type'         => 'reflink',
        'post_parent'       => $casino_id->ID
    ) );
    $rep = get_field('main_links', $reflink[0]->ID);
    $bonus_link = '';
    if ($rep) {
        foreach ($rep as $r) {
            if ($r['title'] == 'bonus_link')
                $bonus_link = $r['referal_link'];
        }
    }

?>
<div class="bonus_item bonus_item-<?= $i; ?>">
    <span class="bonus_code">Bonus Code: <?= get_field( 'code', $bonus_id ); ?></span>
    <div class="bonus_name">
        <img src="<?= wp_get_attachment_url( get_field( 'casino_bonus_logo', $casino_id ) );?>" alt="">
    </div>
    <p class="bonus_title">
        <?= get_field( 'bonus_size', $bonus_id ) ? get_field( 'bonus_size', $bonus_id ) . ' AUD ' : ''; ?>
        <?= ( get_field( 'bonus_size', $bonus_id ) && get_field( 'free_spins', $bonus_id ) ) ? ' + ' : ''; ?>
        <?= get_field( 'free_spins', $bonus_id ) ? get_field( 'free_spins', $bonus_id ) . ' FS' : ''; ?>
    </p>
    <a href="<?= $bonus_link; ?>" class="get_bonus">Get Bonus</a>
    <div class="bonus_details" data-bonus-id="<?= $bonus_id; ?>">Bonus Details</div>
</div>
