<?php $term_id = $args['term_id']; ?>
<div class="subscribe_block">
    <div class="popup_form">
        <div class="close_button"></div>
        <img loading="lazy" class="form_img" src="<?= get_template_directory_uri() ?>/assets/img/form-img.jpg" alt="">
        <form name="sub_form" class="subscribers" method="post" novalidate>
            <div class="form_title">Subscribe Form</div>
            <input type="text" name="sub_name" value="" placeholder="Your Name" required>
            <input type="email" name="sub_email" value="" placeholder="Your Email" required>
            <label for="sub_something">
                <input type="checkbox" id="sub_something" name="sub_something" value="" checked>
                <span>Save my name, email, and website in this browser for the next time I comment.</span>
            </label>
            <input type="hidden" name="action" value="subscribe_user">
            <p class="subscribe_message"></p>
            <input type="submit" value="Subscribe">
        </form>
    </div>
    <p class="sub_title"><?= the_field( 'subscribe_form_text', $term_id ); ?></p>
    <button class="sub_button">Subscribe</button>
</div>

