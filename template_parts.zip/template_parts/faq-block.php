<?php
    if ( is_tax( 'game_category' ) || is_tax( 'casino_type' ) || is_post_type_archive( 'bonus' ) || is_tax( 'bonus_category' ) ) {
        $term_id = $args['page_id'];
    } else
        $term_id = get_queried_object_id();
?>
<section class="faq_block">
    <div class="wrapper">
        <div class="faq_content">
            <h2 class="title_h2"><?= get_field( 'faq_block_title', $term_id ); ?></h2>
            <span><?= get_field( 'faq_block_desc', $term_id ); ?></span>
            <?php $faqs = get_field( 'faq_list', $term_id ); ?>
            <?php if ( $faqs ) : ?>
                <?php $i = 1; ?>
                <div class="faq_items">
                    <?php foreach ( $faqs as $faq ) : ?>
                        <div class="faq_item">
                            <?php if ( $i == 1 ) : ?>
                                <h3 class="faq_question rotate"><span class="fq"><?= $faq['question']; ?></span></h3>
                                <div class="faq_answer"><?= $faq['answer']; ?></div>
                            <?php else : ?>
                                <h3 class="faq_question"><span class="fq"><?= $faq['question']; ?></span></h3>
                                <div class="faq_answer hidden"><?= $faq['answer']; ?></div>
                            <?php endif; ?>
                        </div>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="faq_bg"></div>
</section>
