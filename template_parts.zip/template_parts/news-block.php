<?php $cat_id = $args['cat_id'] ?? $args['cat_id']; ?>
<?php if ( $cat_id ) : ?>
    <?php $news = get_field( 'news_block', 'category_' . $cat_id ); ?>
<?php else : ?>
    <?php $news = get_field( 'news_block', get_queried_object_id() ); ?>
<?php endif; ?>
<?php if ( $news ) : ?>
    <section class="news_block">
        <div class="wrapper">
            <div class="news_content">
                <h2 class="title_h2"><?= $news['main_title']; ?></h2>
                <?php if ( $news['description'] ) : ?>
                    <span><?= $news['description']; ?></span>
                <?php endif; ?>
                <?php $posts = get_posts( array(
                    'numberposts'   => 4,
                    'category_name' => 'news',
                    'order'         => 'DESC'
                ) ); ?>
                <?php if ( $posts ) : ?>
                    <div class="news_items">
                        <?php foreach ( $posts as $post ) : ?>
                            <?php setup_postdata( $post ); ?>
                            <div class="news_item">
                                <img loading="lazy" src="<?= get_the_post_thumbnail_url( $post ); ?>" alt="">
                                <div class="news_info">
                                    <h3><?= the_title(); ?></h3>
                                    <a href="<?= the_permalink(); ?>" class="news_link">Read News</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php wp_reset_postdata(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

