<?php
$is_tax = is_tax( 'game_category' );
$all_games = is_tax( 'casino_type' );
if ( $is_tax || $all_games) {
    $page_id = $args['page_id'];
} else
    $page_id = get_queried_object_id();

$args = array(
    'taxonomy'          => 'game_category',
    'hide_empty'        => false,
    'parent'            => 5,
    'exclude'            => ($all_games)?'10,12,13':'',
    'number'            => 9,
    'orderby'           => 'term_group'
);
$terms = get_terms( $args );
if ( $terms ) :
    ?>
<div class="games_block">
    <h2 class="title_h2"><?= get_field( 'games_block_title', $page_id ); ?></h2>
    <?php if ( $is_tax || $all_games) : ?>
        <div class="descs">
            <p class="desc"><?= get_field( 'games_block_desc1', $page_id ); ?></p>
            <p class="desc"><?= get_field( 'games_block_desc2', $page_id ); ?></p>
        </div>
    <?php else : ?>
        <p class="desc"><?= get_field( 'games_block_desc1', $page_id ); ?></p>
    <?php endif; ?>
    <div class="game_cat_items">
        <?php foreach ( $terms as $term ) : ?>
            <div class="game_cat_item">
                <img loading="lazy" class="game_cat_logo" src="<?= wp_get_attachment_url( get_field( 'category_logo', 'game_category_' . $term->term_id ) ); ?>" alt="">
                <div class="item_text_block">
                    <h3><?= $term->name; ?></h3>
                    <?php if ( is_front_page() ) : ?>
                        <span><?= $term->description; ?></span>
                    <?php else : ?>
                        <?php if(get_field( 'casino_games_page_description', 'game_category_' . $term->term_id )): ?>
                            <span><?= get_field( 'casino_games_page_description', 'game_category_' . $term->term_id ); ?></span>
                        <?php else: ?>
                            <span><?= $term->description; ?></span>
                        <?php endif; ?>
                    <?php endif; ?>
                    <a href="<?= get_term_link( (int) $term->term_id ); ?>">More info</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
