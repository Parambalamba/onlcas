<?php
    $bonus_casino_id = get_field('casino', $bonus_id);
    $bonus = get_post( $bonus_id );
    $casino_id = $bonus->post_parent;
    $tms = wp_get_post_terms( $bonus_id, 'bonus_category', array( 'fields' => 'names' ) );
    $bonus_cat = $tms ? $tms[0] : '';
    $reflink = get_posts( array(
        'numberposts'       => 1,
        'post_type'         => 'reflink',
        'post_parent'       => $casino_id->ID
    ) );
    $rep = get_field('main_links', $reflink[0]->ID);
    $bonus_link = '';
    if ($rep) {
        foreach ($rep as $r) {
            if ($r['title'] == 'bonus_link')
                $bonus_link = $r['referal_link'];
        }
    }

?>
<?php
//$terms = get_the_terms( $bonus_id, 'bonus_categories' );
?>

<div class="close_button"></div>
<div class="modal_header">
    <img loading="lazy" class="form_img" src="<?= wp_get_attachment_url( get_field( 'casino_bonus_logo', $casino_id ) );?>" alt="">
    <div class="modal_head"><?= $bonus_cat; ?>: <?= get_field( 'bonus_size', $bonus_id ) ? get_field( 'bonus_size', $bonus_id ) . ' AUD' : ''; ?>
        <?= get_field( 'free_spins', $bonus_id ) ? ' + ' . get_field( 'free_spins', $bonus_id ) . ' FS' : ''; ?></div>
    <a href="<?= $bonus_link; ?>" class="modal_button">Get Bonus</a>
</div>
<div class="modal_table">
    <div class="head_table">Bonus Details</div>
    <div class="head_items">
        <div class="item">
            <div class="col_left casino">Casino:</div>
            <div class="col_right"><?= get_the_title( $casino_id ); ?></div>
        </div>
        <div class="item">
            <div class="col_left bonus_code">Bonus Code:</div>
            <div class="col_right"><?= get_field( 'code', $bonus_id ); ?></div>
        </div>
        <?php if ( get_field( 'type', $bonus_id ) ) : ?>
            <div class="item">
                <div class="col_left bonus_type">Type:</div>
                <div class="col_right"><?= get_field( 'type', $bonus_id ); ?></div>
            </div>
        <?php endif; ?>
        <div class="item">
            <div class="col_left bonus">Bonus:</div>
            <div class="col_right"><?= get_field( 'bonus_size', $bonus_id ) ?? get_field( 'bonus_size', $bonus_id ) . ' AUD'; ?> </div>
        </div>
        <div class="item">
            <div class="col_left min_deposit">Min Deposit:</div>
            <div class="col_right"><?= get_field( 'min_deposit', $bonus_id ) ?? get_field( 'min_deposit', $bonus_id ) . ' AUD'; ?></div>
        </div>
        <div class="item">
            <div class="col_left free_spins">Free Spins:</div>
            <div class="col_right"><?= get_field( 'free_spins', $bonus_id ) ?? get_field( 'free_spins', $bonus_id ); ?></div>
        </div>
    </div>
</div>
<div class="terms"><?= get_field( 'bonus_rules', $casino_id ); ?></div>







