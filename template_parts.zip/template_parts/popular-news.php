<div class="popular_news">
    <span class="title">Popular Posts</span>
    <?php $posts = get_posts( array(
            'numberposts'   => 4,
            'orderby'       => 'meta_value',
            'meta_key'      => 'views'
    ) ); ?>
    <?php if ( $posts ) : ?>
        <div class="items">
        <?php foreach ( $posts as $p ) : ?>
            <div class="item">
                <img loading="lazy" src="<?= get_the_post_thumbnail_url( $p->ID ); ?>" alt="">
                <div class="item_content">
                    <span class="item_title"><?= get_the_title( $p->ID ); ?></span>
                    <a href="<?= the_permalink( $p ); ?>" class="rmore">Read More</a>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
