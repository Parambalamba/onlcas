<?php $term_id = $args['page_id']; ?>
<section class="bonuses_block">
    <div class="wrapper">
        <div class="bonus_block">
            <h2 class="title_h2 text_left"><?php the_field( 'best_bonus_block_title', $term_id ); ?></h2>
            <?php if ( get_field( 'best_bonus_block_desc', $term_id ) ) : ?>
                <p class="desc"><?php the_field( 'best_bonus_block_desc', $term_id ); ?></p>
            <?php endif; ?>
            <?php if ( get_field( 'enable_subscribe_form', $term_id ) ) : ?>
                <?php get_template_part( 'template_parts/modal', 'subscribe', array( 'term_id' => $term_id ) ); ?>
            <?php endif; ?>
            <?php
            $bonus_items = get_field( 'best_bonus_items', $term_id );
            if ( $bonus_items ) :
                $i = 1;
            ?>
                <div class="items_block">
                    <div class="bonus_modal"></div>
                    <?php
                    foreach ( $bonus_items as $bonus_id ) :
                        $bonus = get_post( $bonus_id );
                        ?>
                            <?php get_template_part( 'template_parts/loop', 'bonus', array( 'bonus_id' => $bonus_id, 'increm' => $i ) ); ?>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>


        </div>
    </div>
</section>
