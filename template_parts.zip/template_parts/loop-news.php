<div class="news_item">
    <img loading="lazy" src="<?= get_the_post_thumbnail_url(); ?>" alt="">
    <div class="news_info">
        <h3><?= get_the_title(); ?></h3>
        <a href="<?= get_the_permalink(); ?>" class="news_link">Read News</a>
    </div>
</div>