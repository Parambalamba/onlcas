<?php $term_id = $args['term_id']; ?>
<section class="main_content">
    <div class="wrapper">
        <div class="top_games_block">
            <div class="top_games_left">
                <h1 class="title_h2"><?= get_field( 'main_content_title', $term_id ); ?></h1>
                <div><?= get_field( 'main_content_desc', $term_id ); ?></div>
                <?php if ( get_field( 'enable_social_links', $term_id ) ) : ?>
                    <div class="contacts_block">
                        <div class="social_block">
                            <span class="contacts_title">social networks:</span>
                            <?php get_template_part( 'template_parts/social', 'links-block' ); ?>
                        </div>
                        <?php if ( get_field( 'enable_email_field' ) ) : ?>
                            <div class="email_field_block">
                                <span class="contacts_title">EMAIL:</span>
                                <a href="mailto:<?= get_field( 'contact_email', 'option' ); ?>"><?= get_field( 'contact_email', 'option' ); ?></a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="top_games_right" style='background-image: url("<?= wp_get_attachment_url( get_field( 'main_content_image', $term_id ) ); ?>") '>
            </div>
        </div>
    </div>
</section>


