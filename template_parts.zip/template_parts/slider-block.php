<?php $page_id = $args['page_id']; ?>
<section class="slider_block">
    <div class="wrapper">
        <div class="slider_block_content">
            <div class="content">
                <h2 class="title_h2"><?= get_field( 'slider_title', $page_id ); ?></h2>
                <div class="desc"><?= get_field( 'slider_desc', $page_id ); ?></div>
                <div class="sl_dots"></div>
            </div>
            <div class="slider">
                <?php $items = get_field( 'slider_block', $page_id ); ?>
                <?php if ( $items ) : ?>
                    <?php foreach ( $items as $item ) : ?>
                        <div class="item">
                            <div class="head">
                                <img loading="lazy" src="<?= wp_get_attachment_url( $item['image'] ); ?>" alt="">
                                 <h3 class="title_h3"><?= $item['title']; ?></h3>
                            </div>
                            <div class="foot"><?= $item['desc']; ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
