<?php if ( is_tax( 'game_category' ) ) : ?>
    <?php $term_id = 'game_category_' . $args['page_id']; ?>
<?php elseif(is_tax( 'casino_type' )): ?>
    <?php $term_id = 'casino_type_' . $args['page_id']; ?>
<?php else : ?>
    <?php $term_id = $args['page_id']; ?>
<?php endif; ?>

<section class="casino_bonuses">
    <div class="wrapper">
        <div class="custom_row">
            <div class="col_left">
                <?php if(get_field('casino_bonuses_-_text_block_-_title', $term_id )):  ?>
                    <h2 class="title_h2 text_left"><?php the_field( 'casino_bonuses_-_text_block_-_title', $term_id ); ?></h2>
                <?php endif; ?>
                <?php if(get_field( 'casino_bonuses_-_text_block_-_desc', $term_id )):  ?>
                    <div class="casino_bonuses_text text">
                        <?php the_field( 'casino_bonuses_-_text_block_-_desc', $term_id ); ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php if(get_field(  'casino_bonuses_-_text_block_-_img_desktop', $term_id )):  ?>
                <div class="col_right">

                        <?php if(get_field( 'casino_bonuses_-_text_block_-_img_mobile', $term_id )):  ?>
                    <picture>
                            <source media="(max-width: 1201px)" srcset="<?php the_field( 'casino_bonuses_-_text_block_-_img_mobile', $term_id ); ?>" class="img_mobile">
                            <img src="<?php the_field( 'casino_bonuses_-_text_block_-_img_mobile', $term_id ); ?>" alt="" class="img_mobile">
                    </picture>
                        <?php endif; ?>
                        <?php if(get_field(  'casino_bonuses_-_text_block_-_img_desktop', $term_id  )):  ?>
                        <picture>
                            <source srcset="<?php the_field( 'casino_bonuses_-_text_block_-_img_desktop', $term_id ); ?>" class="img_desktop">
                            <img src="<?php the_field( 'casino_bonuses_-_text_block_-_img_desktop', $term_id ); ?>" alt="" class="img_desktop">
                        </picture>
                        <?php endif; ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</section>