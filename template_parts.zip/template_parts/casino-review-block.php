<?php if ( is_tax( 'game_category' ) ) : ?>
    <?php $term_id = 'game_category_' . $args['page_id']; ?>
<?php elseif(is_tax( 'casino_type' )): ?>
    <?php $term_id = 'casino_type_' . $args['page_id']; ?>
<?php else : ?>
    <?php $term_id = $args['page_id']; ?>
<?php endif; ?>


<section class="casino_reviews_block">
    <div class="wrapper">
        <div class="casino_reviews_content">
            <?php if(get_field('casino_reviews_block_-_title', $term_id )):  ?>
                <h2 class="title_h2"><?php the_field( 'casino_reviews_block_-_title', $term_id ); ?></h2>
            <?php endif; ?>
            <?php if(get_field('casino_reviews_block_-_desc', $term_id )):  ?>
                <div class="cr_desc"><?php the_field( 'casino_reviews_block_-_desc', $term_id ); ?></div>
            <?php endif; ?>
            <?php if( have_rows('casino_reviews_block_-_cards',$term_id) ): ?>
                <div class="items">
                    <?php while( have_rows('casino_reviews_block_-_cards',$term_id) ): the_row(); ?>
                        <div class="item">
                            <div class="first_line">
                                <img loading="lazy" src="<?php the_sub_field('casino_reviews_block_-_cards_icon',$term_id); ?>" alt="">
                                <h3><?php the_sub_field('casino_reviews_block_-_cards_title',$term_id); ?></h3>
                            </div>
                            <span><?php the_sub_field('casino_reviews_block_-_cards_desc',$term_id); ?></span>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
            <div class="casino_reviews_content_bottom">
                <?php if(get_field('casino_reviews_block_-_bottom_title', $term_id )):  ?>
                    <h2 class="title_h2 text_left"><?php the_field( 'casino_reviews_block_-_bottom_title', $term_id ); ?></h2>
                <?php endif; ?>
                <?php if(get_field('casino_reviews_block__-_bottom_desc', $term_id )):  ?>
                    <div class="text_left"><?php the_field( 'casino_reviews_block__-_bottom_desc', $term_id ); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

