<div class="item">
    <img loading="lazy" src="<?= wp_get_attachment_url( get_field( 'game_image', get_the_ID() ) ); ?>" alt="">
    <div class="pl_link">
        <span class="game_name"><?= get_the_title(); ?></span>
        <a href="<?= get_field( 'referal_link', get_the_ID() ) ?>" class="play_link">Play Now</a>
        <!--<a href="<?= get_the_permalink(); ?>" class="review_link">Read Review</a>-->
    </div>
</div>
