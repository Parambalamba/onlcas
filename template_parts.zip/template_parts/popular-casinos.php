<div class="popular_casinos">
    <span class="title">Popular Online Casino</span>
    <?php $casinos = get_field( 'popular_casino' ); ?>
    <?php if ( $casinos ) : ?>
        <div class="items">
            <?php foreach ( $casinos as $casino_id ) : ?>
                <?php $bonus_id = get_field( 'start_bonus', $casino_id ); ?>
                <div class="item">
                    <img loading="lazy" src="<?= wp_get_attachment_url( get_field( 'casino_logo_horizontal', $casino_id ) ); ?>" alt="">
                    <a href="<?= get_the_permalink( $casino_id ); ?>" class="bonus"><?= get_field( 'bonus_size', $bonus_id ) ? get_field( 'bonus_size', $bonus_id ) . ' AUD' : ''; ?>
                        <?= get_field( 'free_spins', $bonus_id ) ? ' + ' . get_field( 'free_spins', $bonus_id ) . ' FS' : ''; ?></a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <a href="<?= get_term_link( 'real-money-casinos', 'casino_type' ); ?>" class="more_casinos">More Online Casinos</a>
</div>
