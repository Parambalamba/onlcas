<?php if ( have_rows( 'social_links', 'option' ) ) : ?>
<div class="social_links">
<?php while ( have_rows( 'social_links', 'option' ) ) : the_row(); ?>
    <!--<a href="<?= get_sub_field( 'follow_link' ); ?>">-->
    <span>
        <?= file_get_contents( wp_get_original_image_path( get_sub_field( 'icon' ) ) ); ?>
    </span>
    <!--</a>-->
    <?php endwhile; ?>
</div>
<?php endif; ?>
