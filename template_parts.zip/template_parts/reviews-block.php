<?php $page_id = $args['game_id']; ?>
<section class="slider_block">
    <div class="wrapper">
        <div class="slider_block_content">
            <div class="content">
                <h2 class="title_h2"><?= get_field( 'reviews_title' ); ?></h2>
                <div class="desc"><?= get_field( 'reviews_desc' ); ?></div>
                <div class="sl_dots"></div>
            </div>
            <div class="slider">
                <?php
                $args = array(
                    'post_type'         => 'post',
                    'posts_per_page'    => -1,
                    'category_name'     => 'reviews',
                    'meta_key'          => 'game',
                    'meta_value'        => $page_id
                );
                $reviews = get_posts( $args );
                ?>
                <?php if ( reviews ) : ?>
                    <?php foreach ( $reviews as $item ) : ?>
                        <div class="item">
                            <div class="head">
                                <img loading="lazy" src="<?= get_the_post_thumbnail_url( $item->ID ); ?>" alt="">
                                <div class="rev_title">
                                    <img loading="lazy" src="<?= get_template_directory_uri() ?>/assets/img/stars.png" alt="">
                                    <h3 class="title_h3"><?= $item->post_title; ?></h3>
                                </div>
                            </div>
                            <div class="foot"><?= $item->post_content; ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
