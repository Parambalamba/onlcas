<?php
if ( is_tax( 'game_category' ) || is_tax( 'casino_type' )) {
    $term_id = $args['page_id'];
} else
    $term_id = get_queried_object_id();
?>

<section class="pokies_block">
    <div class="wrapper">
        <div class="about_content">
            <?php
                $left_link_text=get_field( 'left_link_text', $term_id );
                $right_img=get_field( 'right_image', $term_id );
                if($right_img):
            ?>
                <img loading="lazy" src="<?php echo $right_img; ?>" alt="<?php echo get_field( 'left_title', $term_id ); ?>">
            <?php endif; ?>
            <div class="text_block">
                <h2 class="title_h2"><?php echo get_field( 'left_title', $term_id ); ?></h2>
                <span><?php echo get_field( 'left_desc', $term_id ); ?></span>
                <?php if($left_link_text): ?>
                    <a href="<?php echo get_field( 'left_link_href', $term_id ); ?>" class="about_link"><?php echo get_field( 'left_link_text', $term_id ); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
