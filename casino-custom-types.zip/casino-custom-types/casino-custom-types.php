<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://example.com
 * @since             1.0.0
 * @package           Сasino_Custom_Types
 *
 * @wordpress-plugin
 * Plugin Name:       Casino Custom Types
 * Plugin URI:        http://example.com/plugin-name-uri/
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Sergei Konovalov
 * Author URI:        http://example.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       casino-custom-types
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'CASINO-CUSTOM-TYPES_VERSION', '1.0.0' );
!defined('CASINO_CUSTOM_TYPES_PATH') && define('CASINO_CUSTOM_TYPES_PATH', plugin_dir_path( __FILE__ ));

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-plugin-name-activator.php
 */
function activate_casino_custom_types() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-casino-custom-types-activator.php';
	Casino_Custom_Types_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-plugin-name-deactivator.php
 */
function deactivate_casino_custom_types() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-casino-custom-types-deactivator.php';
	Casino_Custom_Types_Deactivator::deactivate();
}

/**
 * Adds Settings link after plugin activated
 */
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'my_plugin_settings' );
function my_plugin_settings( $settings ) {
    $settings[] = '<a href="'. get_admin_url(null, 'admin.php?page=casino_custom_types') .'">Settings</a>';
    return $settings;
}


/**
 * Register custom post_types
 */
add_action( 'init', 'register_custom_post_type' );
function register_custom_post_type() {
    if ( get_option( 'casino_plugin_setting_casinos' ) ) {
        // тип записи - вопросы - faq
        register_post_type('casino', [
            'label' => 'Casinos',
            'labels' => array(
                'name' => 'Casino',
                'singular_name' => 'Casino',
                'menu_name' => "Casinos",
                'all_items' => 'All Casinos',
                'add_new' => 'Add Casino',
                'add_new_item' => 'Add New Casino',
                'edit' => 'Edit',
                'edit_item' => 'Edit Casino',
                'new_item' => 'New Casino',
            ),
            'description' => 'Collect info and description of registered Online Casinos',
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_rest' => false,
            'rest_base' => '',
            'show_in_menu' => true,
            'exclude_from_search' => false,
            'capability_type' => 'post',
            'map_meta_cap' => true,
            'hierarchical' => true,
            'rewrite' => array('slug' => '', 'with_front' => true),
            'has_archive' => false,
            'query_var' => true,
            'supports' => array('title', 'editor'),
            'taxonomies' => array('casino_type'),
        ]);

        register_taxonomy('casino_type', ['casino'], [
            'label' => '', // определяется параметром $labels->name
            'labels' => [
                'name' => 'Casino Types',
                'singular_name' => 'Casino Type',
                'search_items' => 'Search Casino Type',
                'all_items' => 'All Casino Types',
                'view_item ' => 'View Casino Type',
                'parent_item' => 'Parent Casino Type',
                'parent_item_colon' => 'Parent Casino Type:',
                'edit_item' => 'Edit Casino Type',
                'update_item' => 'Update Casino Type',
                'add_new_item' => 'Add New Casino Type',
                'new_item_name' => 'New Casino Type Name',
                'menu_name' => 'Casino Types',
            ],
            'description' => '', // описание таксономии
            'public' => true,
            // 'publicly_queryable'    => null, // равен аргументу public
            // 'show_in_nav_menus'     => true, // равен аргументу public
            // 'show_ui'               => true, // равен аргументу public
            // 'show_in_menu'          => true, // равен аргументу show_ui
            // 'show_tagcloud'         => true, // равен аргументу show_ui
            // 'show_in_quick_edit'    => null, // равен аргументу show_ui
            'hierarchical' => true,

            'rewrite' => array('slug' => '', 'with_front' => true),
            //'query_var'             => $taxonomy, // название параметра запроса
            'capabilities' => array(),
            'meta_box_cb' => null, // html метабокса. callback: `post_categories_meta_box` или `post_tags_meta_box`. false — метабокс отключен.
            'show_admin_column' => true, // авто-создание колонки таксы в таблице ассоциированного типа записи. (с версии 3.5)
            'show_in_rest' => null, // добавить в REST API
            'rest_base' => null, // $taxonomy
            // '_builtin'              => false,
            //'update_count_callback' => '_update_post_term_count',
        ]);
    }

    if ( get_option( 'casino_plugin_setting_games' ) ) {
        register_post_type('game', [
            'label' => 'Casino Games',
            'labels' => array(
                'name' => 'Casino Games',
                'singular_name' => 'Casino Game',
                'menu_name' => "Casino Games",
                'all_items' => 'All Casino Games',
                'add_new' => 'Add Casino Game',
                'add_new_item' => 'Add New Casino Game',
                'edit' => 'Edit',
                'edit_item' => 'Edit Casino Game',
                'new_item' => 'New Casino Game',
            ),
            'description' => 'Collect info and description of registered Casino Games',
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_rest' => false,
            'rest_base' => '',
            'show_in_menu' => true,
            'exclude_from_search' => false,
            'capability_type' => 'post',
            'map_meta_cap' => true,
            'hierarchical' => false,
            'rewrite' => array('slug' => 'casino-games/%games%', 'with_front' => false, 'hierarchical' => false),
            'has_archive' => false,
            'query_var' => true,
            'supports' => array('title', 'editor'),
            'taxonomies' => array('game_category'),
        ]);

        register_taxonomy('game_category', ['game'], [
            'label' => '', // определяется параметром $labels->name
            'labels' => [
                'name' => 'Game Categories',
                'singular_name' => 'Game Category',
                'search_items' => 'Search Game Category',
                'all_items' => 'All Game Categories',
                'view_item ' => 'View Game Category',
                'parent_item' => 'Parent Game Category',
                'parent_item_colon' => 'Parent Game Category:',
                'edit_item' => 'Edit Game Category',
                'update_item' => 'Update Game Category',
                'add_new_item' => 'Add New Game Category',
                'new_item_name' => 'New Game Category Name',
                'menu_name' => 'Game Categories',
            ],
            'description' => '', // описание таксономии
            'public' => true,
            // 'publicly_queryable'    => null, // равен аргументу public
            // 'show_in_nav_menus'     => true, // равен аргументу public
            // 'show_ui'               => true, // равен аргументу public
            // 'show_in_menu'          => true, // равен аргументу show_ui
            // 'show_tagcloud'         => true, // равен аргументу show_ui
            // 'show_in_quick_edit'    => null, // равен аргументу show_ui
            'hierarchical' => true,

            'rewrite' => array('slug' => '', 'with_front' => false),
            //'query_var'             => $taxonomy, // название параметра запроса
            'capabilities' => array(),
            'meta_box_cb' => null, // html метабокса. callback: `post_categories_meta_box` или `post_tags_meta_box`. false — метабокс отключен.
            'show_admin_column' => true, // авто-создание колонки таксы в таблице ассоциированного типа записи. (с версии 3.5)
            'show_in_rest' => null, // добавить в REST API
            'rest_base' => null, // $taxonomy
            // '_builtin'              => false,
            //'update_count_callback' => '_update_post_term_count',
        ]);

    }

    if ( get_option( 'casino_plugin_setting_bonuses' ) ) {
        register_post_type('bonus', [
            'label' => 'Casino Bonuses',
            'labels' => array(
                'name' => 'Casino Bonus',
                'singular_name' => 'Casino Bonus',
                'menu_name' => "Casino Bonuses",
                'all_items' => 'All Casino Bonuses',
                'add_new' => 'Add Casino Bonus',
                'add_new_item' => 'Add New Casino Bonus',
                'edit' => 'Edit',
                'edit_item' => 'Edit Casino Bonus',
                'new_item' => 'New Casino Bonus',
            ),
            'description' => 'Collect info and description of registered Casinos bonuses',
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_rest' => false,
            'rest_base' => '',
            'show_in_menu' => true,
            'exclude_from_search' => false,
            'capability_type' => 'post',
            'map_meta_cap' => true,
            'hierarchical' => true,
            'rewrite' => array('slug' => 'casino-bonuses', 'with_front' => true),
            'has_archive' => true,
            'query_var' => true,
            'supports' => array('title', 'editor'),
            'taxonomies' => array( 'bonus_category' ),
        ]);

        register_taxonomy('bonus_category', ['bonus'], [
            'label' => '', // определяется параметром $labels->name
            'labels' => [
                'name' => 'Bonus Categories',
                'singular_name' => 'Bonus Category',
                'search_items' => 'Search Bonus Category',
                'all_items' => 'All Bonus Categories',
                'view_item ' => 'View Bonus Category',
                'parent_item' => 'Parent Bonus Category',
                'parent_item_colon' => 'Parent Bonus Category:',
                'edit_item' => 'Edit Bonus Category',
                'update_item' => 'Update Bonus Category',
                'add_new_item' => 'Add New Bonus Category',
                'new_item_name' => 'New Bonus Category Name',
                'menu_name' => 'Bonus Categories',
            ],
            'description' => '', // описание таксономии
            'public' => true,
            // 'publicly_queryable'    => null, // равен аргументу public
            // 'show_in_nav_menus'     => true, // равен аргументу public
            // 'show_ui'               => true, // равен аргументу public
            // 'show_in_menu'          => true, // равен аргументу show_ui
            // 'show_tagcloud'         => true, // равен аргументу show_ui
            // 'show_in_quick_edit'    => null, // равен аргументу show_ui
            'hierarchical' => true,

            'rewrite' => array('slug' => 'casino-bonuses', 'with_front' => true),
            //'query_var'             => $taxonomy, // название параметра запроса
            'capabilities' => array(),
            'meta_box_cb' => null, // html метабокса. callback: `post_categories_meta_box` или `post_tags_meta_box`. false — метабокс отключен.
            'show_admin_column' => true, // авто-создание колонки таксы в таблице ассоциированного типа записи. (с версии 3.5)
            'show_in_rest' => null, // добавить в REST API
            'rest_base' => null, // $taxonomy
            // '_builtin'              => false,
            //'update_count_callback' => '_update_post_term_count',
        ]);

        // Добавим метабокс выбора Казино к бонусу
        add_action('add_meta_boxes', function () {
            add_meta_box( 'bonus_casino', 'Casino', 'bonus_casino_metabox', 'bonus', 'side', 'low'  );
        }, 1);

// метабокс с селектом команд
        function bonus_casino_metabox( $post ){
            $teams = get_posts(array( 'post_type'=>'casino', 'posts_per_page'=>-1, 'orderby'=>'post_title', 'order'=>'ASC' ));

            if( $teams ){
                // чтобы портянка пряталась под скролл...
                echo '
		<div style="max-height:200px; overflow-y:auto;">
			<ul>
		';

                foreach( $teams as $team ){
                    echo '
			<li><label>
				<input type="radio" name="post_parent" value="'. $team->ID .'" '. checked($team->ID, $post->post_parent, 0) .'> '. esc_html($team->post_title) .'
			</label></li>
			';
                }

                echo '
			</ul>
		</div>';
            }
            else
                echo 'Команд нет...';
        }

    }

    if ( get_option( 'casino_plugin_setting_reflinks' ) ) {
        register_post_type('reflink', [
            'label' => 'Referal Links',
            'labels' => array(
                'name' => 'Referal Links',
                'singular_name' => 'Referal Links',
                'menu_name' => "Referal Links",
                'all_items' => 'All Referal Links',
                'add_new' => 'Add Referal Links',
                'add_new_item' => 'Add New Referal Links',
                'edit' => 'Edit',
                'edit_item' => 'Edit Referal Links',
                'new_item' => 'New Referal Links',
            ),
            'description' => 'Collect referal links for casino',
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_rest' => false,
            'rest_base' => '',
            'show_in_menu' => true,
            'exclude_from_search' => false,
            'capability_type' => 'post',
            'map_meta_cap' => true,
            'hierarchical' => true,
            'rewrite' => array('slug' => '', 'with_front' => true),
            'has_archive' => false,
            'query_var' => true,
            'supports' => array( 'title' ),
            'taxonomies' => array( '' ),
        ]);

        // Добавим метабокс выбора Казино к реферальным ссылкам
        add_action('add_meta_boxes', function () {
            add_meta_box( 'reflink_casino', 'Casino', 'bonus_casino_metabox', 'reflink', 'side', 'low'  );
        }, 1);

    }
}

/**
 * Change URL for custom post type of term real-money-casinos of taxonomy casino_type
 */
if ( get_option( 'casino_plugin_setting_casinos') ) {
    add_filter('post_type_link', 'add_casino_permalinks', 1, 2);
    function add_casino_permalinks($post_link, $post)
    {
        if (is_object($post) && $post->post_type == 'casino') {
            $terms = wp_get_object_terms($post->ID, 'casino_type');
            if ($terms) {
                return str_replace('/casino/', '/' . $terms[0]->slug . '/', $post_link);
            }
        }

        return $post_link;
    }
}

/**
 * Change URL for custom post type with all hierarchical terms of taxonomy game_category
 */
if ( get_option( 'casino_plugin_setting_games') ) {
    ## Отфильтруем ЧПУ произвольного типа
// сам фильтр: apply_filters( 'post_type_link', $post_link, $post, $leavename, $sample );
    add_filter('post_type_link', 'games_permalink', 1, 2);

    function games_permalink( $permalink, $post ){
        // выходим если это не наш тип записи: без холдера %products%
        if( strpos($permalink, '%games%') === FALSE )
            return $permalink;

        // Получаем элементы таксы
        $terms = get_the_terms($post, 'game_category');
        $wpseo_primary_term = new WPSEO_Primary_Term( 'game_category', get_the_id() );
        $wpseo_primary_term = $wpseo_primary_term->get_primary_term();
        $term = get_term( $wpseo_primary_term );
        // если есть элемент заменим холдер
        if( ! is_wp_error($term) && !empty($terms) )
            $taxonomy_slug = $term->slug;
        // элемента нет, а должен быть...
        else
            $taxonomy_slug = 'no-games';

        return str_replace('%games%', $taxonomy_slug, $permalink );
    }

}

/**
 * Add to child term url the parent term
 */
if ( get_option( 'casino_plugin_setting_games') ) {

    add_filter( 'term_link', 'term_link_filter', 10, 3 );
    function term_link_filter( $url, $term, $taxonomy )
    {
        if ( $taxonomy == 'game_category' && $term->parent != 0 ) {
            $new_term = get_term( $term->parent, $taxonomy );
            return site_url() . '/' . $new_term->slug . '/' . $term->slug . '/';
        }
        if ( $taxonomy == 'game_category' && !$term->parent ) {
            return site_url() . '/' . $term->slug . '/';
        }
        if ( $taxonomy == 'casino_type' && $term) {
            return site_url() . '/' . $term->slug . '/';
        }
        return $url;
    }
}

/**
 * Assign template single-casino for term of taxonomy real-money-casinos
 */
function generated_rewrite_rules() {
    if ( get_option( 'casino_plugin_setting_casinos') ) {
        add_rewrite_rule(
            '^real-money-casinos/(.*)/?$',
            'index.php?post_type=casino&name=$matches[1]',
            'top'
        );
        add_rewrite_rule(
            '^real-money-casinos/?$',
            'index.php?casino_type=real-money-casinos',
            'top'
        );
    }
    if ( get_option( 'casino_plugin_setting_games') ) {
        add_rewrite_rule(
            '^casino-games/([^/]*?)/([^/]*?)$',
            'index.php?post_type=game&game_category=$matches[1]&name=$matches[2]',
            'top'
        );

        add_rewrite_rule(
            '^casino-games/(.*)/?$',
            'index.php?game_category=$matches[1]',
            'top'
        );

        add_rewrite_rule(
            '^casino-games/?$',
            'index.php?game_category=casino-games',
            'top'
        );
        add_rewrite_rule(
            '^casino-bonuses/(.*)/?$',
            'index.php?bonus_category=$matches[1]',
            'top'
        );

    }

}
add_action( 'init', 'generated_rewrite_rules' );


register_activation_hook( __FILE__, 'activate_casino_custom_types' );
register_deactivation_hook( __FILE__, 'deactivate_casino_custom_types' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-casino-custom-types.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_casino_custom_types() {

	$plugin = new Casino_Custom_Types();
	$plugin->run();

}
run_casino_custom_types();
