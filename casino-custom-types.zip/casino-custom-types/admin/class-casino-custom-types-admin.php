<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Casino_Custom_Types
 * @subpackage Casino_Custom_Types/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Casino_Custom_Types
 * @subpackage Casino_Custom_Types/admin
 * @author     Your Name <email@example.com>
 */
class Casino_Custom_Types_Admin
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $plugin_name The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $version The current version of this plugin.
     */
    private $version;

    /**
     * The options name to be used in this plugin
     * @var string
     */
    private $option_name = 'casino_plugin_setting';

    /**
     * Initialize the class and set its properties.
     *
     * @param string $plugin_name The name of this plugin.
     * @param string $version The version of this plugin.
     * @since    1.0.0
     */
    public function __construct($plugin_name, $version)
    {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Plugin_Name_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Plugin_Name_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/casino-custom-types-admin.css', array(), $this->version, 'all');

    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Plugin_Name_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Plugin_Name_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/casino-custom-types-admin.js', array('jquery'), $this->version, false);

    }

    public function register_casino_plugin_settings()
    {
        add_settings_section(
            $this->option_name . '_general',
            __('General', 'casino-custom-types'),
            array($this, $this->option_name . '_general_cb'),
            $this->plugin_name
        );
        add_settings_field(
            $this->option_name . '_bonuses',
            __('Add Bonus Custom Type', 'casino-custom-types'),
            array($this, $this->option_name . '_bonuses_cb'),
            $this->plugin_name,
            $this->option_name . '_general',
            array('label_for' => $this->option_name . '_bonuses')
        );
        add_settings_field(
            $this->option_name . '_casinos',
            __('Add Casino Custom Type', 'casino-custom-types'),
            array($this, $this->option_name . '_casinos_cb'),
            $this->plugin_name,
            $this->option_name . '_general',
            array('label_for' => $this->option_name . '_casinos')
        );
        add_settings_field(
            $this->option_name . '_games',
            __('Add Casino Game Custom Type', 'casino-custom-types'),
            array($this, $this->option_name . '_games_cb'),
            $this->plugin_name,
            $this->option_name . '_general',
            array('label_for' => $this->option_name . '_games')
        );
        add_settings_field(
            $this->option_name . '_reflinks',
            __('Add Referal Link Custom Type', 'casino-custom-types'),
            array($this, $this->option_name . '_reflinks_cb'),
            $this->plugin_name,
            $this->option_name . '_general',
            array('label_for' => $this->option_name . '_reflinks')
        );

        register_setting($this->plugin_name, $this->option_name . '_bonuses', array( $this, $this->option_name . '_sanitize_bonuses' ) );
        register_setting($this->plugin_name, $this->option_name . '_casinos', array( $this, $this->option_name . '_sanitize_casinos' ) );
        register_setting($this->plugin_name, $this->option_name . '_games', array( $this, $this->option_name . '_sanitize_games' ) );
        register_setting($this->plugin_name, $this->option_name . '_reflinks', array( $this, $this->option_name . '_sanitize_reflinks' ) );
    }

    /**
     * Render text for general section
     */
    public function casino_plugin_setting_general_cb()
    {
        echo '<p>' . __('Please choose custom types for adding to site', 'casino-custom-types') . '</p>';
    }

    /**
     * Render text for Bonus field
     */
    public function casino_plugin_setting_bonuses_cb()
    {
        $val = get_option($this->option_name . '_bonuses');
        echo '<input type="checkbox" name="' . $this->option_name . '_bonuses' . '" id="' . $this->option_name . '_bonuses' . '" value="' . $val . '" ' . checked( $val, true, false ) . '> ' . __('Add Bonus Custom Type', 'casino-custom-types');

    }

    /**
     * Render text for Casino field
     */
    public function casino_plugin_setting_casinos_cb()
    {
        $val = get_option($this->option_name . '_casinos');
        echo '<input type="checkbox" name="' . $this->option_name . '_casinos' . '" id="' . $this->option_name . '_casinos' . '" value="' . $val . '" '  . checked( $val, true, false ) . '> ' . __('Add Casino Custom Type', 'casino-custom-types');
    }

    /**
     * Render text for Game field
     */
    public function casino_plugin_setting_games_cb()
    {
        $val = get_option($this->option_name . '_games');
        echo '<input type="checkbox" name="' . $this->option_name . '_games' . '" id="' . $this->option_name . '_games' . '" value="' . $val . '" '  . checked( $val, true, false ) . '> ' . __('Add Game Custom Type', 'casino-custom-types');
    }

    /**
     * Render text for Ref Links field
     */
    public function casino_plugin_setting_reflinks_cb()
    {
        $val = get_option($this->option_name . '_reflinks');
        echo '<input type="checkbox" name="' . $this->option_name . '_reflinks' . '" id="' . $this->option_name . '_reflinks' . '" value="' . $val . '" '  . checked( $val, true, false ) . '> ' . __('Add Referal Link Custom Type', 'casino-custom-types');
    }

    /**
     * Include the setting page
     *
     * @since  1.0.0
     * @access public
     */
    function casino_custom_types_init(){
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        include CASINO_CUSTOM_TYPES_PATH . 'admin/partials/casino-custom-types-admin-display.php' ;
    }

    public function casino_custom_types_plugin_setup_menu(){
        add_menu_page( 'Casino Custom Types settings', 'Casino Custom Types', 'manage_options', 'casino_custom_types', array($this, 'casino_custom_types_init'), 'dashicons-welcome-learn-more' );
    }

    public function casino_plugin_setting_sanitize_bonuses( $input ) {
        return ( isset( $input ) ? true : false );
    }

    public function casino_plugin_setting_sanitize_casinos( $input ) {
        return ( isset( $input ) ? true : false );
    }

    public function casino_plugin_setting_sanitize_games( $input ) {
        return ( isset( $input ) ? true : false );
    }

    public function casino_plugin_setting_sanitize_reflinks( $input ) {
        return ( isset( $input ) ? true : false );
    }

}
